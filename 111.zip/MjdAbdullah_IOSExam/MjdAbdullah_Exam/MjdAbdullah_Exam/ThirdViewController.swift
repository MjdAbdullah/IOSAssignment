//
//  ThirdViewController.swift
//  MjdAbdullah_Exam
//
//  Created by admin on 07/12/2021.
//

import UIKit

class ThirdViewController: UIViewController {
    var message = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblMessage.text = message
    }
    override func viewDidAppear(_ animated: Bool) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var lblMessage: UILabel!
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
