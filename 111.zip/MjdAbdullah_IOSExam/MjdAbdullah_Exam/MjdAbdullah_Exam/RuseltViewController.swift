//
//  RuseltViewController.swift
//  MjdAbdullah_Exam
//
//  Created by admin on 07/12/2021.
//

import UIKit

class RuseltViewController: UIViewController {
    var secor = 0
    var answer = ""
    var massege = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        lblScore.text = "Score +1"
        lblAnswer.text = answer
        lblMassege.text = massege
    }
    
    override func viewDidAppear(_ animated: Bool) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var lblAnswer: UILabel!
    @IBOutlet weak var lblMassege: UILabel!
    @IBOutlet weak var lblScore: UILabel!
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
