//
//  ViewController.swift
//  MjdAbdullah_Exam
//
//  Created by admin on 07/12/2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       setQe()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        setQe()
    }
    
    struct QuizData {
        var data = [
            Dataset(
                questionString: "Who was one of the creators of the Swift language?",
                correctAnswer: 1,
                answerA: "Steve Jobs",
                answerB: "Chris Lattner",
                answerC: "Steve Wozniak",
                answerD: "Ronald Wayne"
            ),
            Dataset(
                questionString: "Apple was created in what year?",
                correctAnswer: 0,
                answerA: "1976",
                answerB: "1989",
                answerC: "1990",
                answerD: "2002"
            ),
            Dataset(
                questionString: "The first iPhone was released on what day?",
                correctAnswer: 0,
                answerA: "Jun 2007",
                answerB: "October 2010",
                answerC: "May 2011",
                answerD: "June 2011"
            ),
            Dataset(
                questionString: "The current ihone has 60GB RAM. The first iPhone had how much RAM?",
                correctAnswer: 2,
                answerA: "1 GB",
                answerB: "3 GB",
                answerC: "128 MB",
                answerD: "It had no RAM"
            ),
            Dataset(
                questionString: "When was  Objective-C Created?",
                correctAnswer: 3,
                answerA: "Jun 2007",
                answerB: "October 2010",
                answerC: "May 2011",
                answerD: "June 2011"
            ),
            
        ]
    }
    
    struct Dataset{
        var questionString = String()
        var correctAnswer = Int()
        var answerA = String()
        var answerB = String()
        var answerC = String()
        var answerD = String()
    }
    
    var currentQuestion = 0
    var score = 0
    let qData = QuizData()
    var Answer = 5
    var cAnswer = ""
    
    @IBOutlet weak var lblQuestion: UILabel!
    @IBOutlet weak var b1: UIButton!
    @IBAction func b1(_ sender: UIButton) {
        
        if checkAnswer(userChoice: 0){
            let vcSecond = storyboard?.instantiateViewController(withIdentifier: "Ruselt") as! RuseltViewController
            vcSecond.massege = "CORRECT!"
            vcSecond.answer = cAnswer
            present(vcSecond, animated: true, completion: nil)
        }else{
            let vcThird = storyboard?.instantiateViewController(withIdentifier: "Third") as! ThirdViewController
            vcThird.message = "NOT QOIITE"
            present(vcThird, animated: true, completion: nil)
        }
    }
    @IBOutlet weak var b2: UIButton!
    @IBAction func b2(_ sender: UIButton) {
        if checkAnswer(userChoice: 1){
            let vcSecond = storyboard?.instantiateViewController(withIdentifier: "Ruselt") as! RuseltViewController
            vcSecond.massege = "CORRECT!"
            vcSecond.answer = cAnswer
            present(vcSecond, animated: true, completion: nil)
        }else{
            let vcThird = storyboard?.instantiateViewController(withIdentifier: "Third") as! ThirdViewController
            vcThird.message = "NOT QOIITE"
            present(vcThird, animated: true, completion: nil)
        }
    }
    @IBOutlet weak var b3: UIButton!
    @IBAction func b3(_ sender: UIButton) {
        if checkAnswer(userChoice: 2){
            let vcSecond = storyboard?.instantiateViewController(withIdentifier: "Ruselt") as! RuseltViewController
            vcSecond.massege = "CORRECT!"
            vcSecond.answer = cAnswer
            present(vcSecond, animated: true, completion: nil)
        }else{
            let vcThird = storyboard?.instantiateViewController(withIdentifier: "Third") as! ThirdViewController
            vcThird.message = "NOT QOIITE"
            present(vcThird, animated: true, completion: nil)
        }
    }
    @IBOutlet weak var b4: UIButton!
    @IBAction func b4(_ sender: UIButton) {
        if checkAnswer(userChoice: 3){
            let vcSecond = storyboard?.instantiateViewController(withIdentifier: "Ruselt") as! RuseltViewController
            vcSecond.massege = "CORRECT!"
            vcSecond.answer = cAnswer
            present(vcSecond, animated: true, completion: nil)
        }else{
            let vcThird = storyboard?.instantiateViewController(withIdentifier: "Third") as! ThirdViewController
            vcThird.message = "NOT QOIITE"
            present(vcThird, animated: true, completion: nil)
        }
    }
    

    func setQe(){
        if currentQuestion == qData.data.count  {
            let vcThird = storyboard?.instantiateViewController(withIdentifier: "Third") as! ThirdViewController
            vcThird.message = "our Score is: \(score) out of 5"
            present(vcThird, animated: true, completion: nil)
            currentQuestion = 0
        }
        let Q = qData.data[currentQuestion]
        lblQuestion.text = Q.questionString
        b1.setTitle(Q.answerA, for: .normal)
        b2.setTitle(Q.answerB, for: .normal)
        b3.setTitle(Q.answerC, for: .normal)
        b4.setTitle(Q.answerD, for: .normal)
        Answer = Q.correctAnswer
        switch Answer {
        case 0: cAnswer = Q.answerA
        case 1: cAnswer = Q.answerB
        case 2: cAnswer = Q.answerC
        case 3: cAnswer = Q.answerD
        default : print("Error")
        }
        currentQuestion += 1
    }
    
    func checkAnswer(userChoice: Int) -> Bool{
        if userChoice == Answer {
            score += 1
            return true
        }
        return false
    }
}

